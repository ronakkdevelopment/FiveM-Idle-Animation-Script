fx_version 'cerulean'
game 'gta5'

author 'Ronakk'
description 'New idle animation for fivem'
version '1.0.0'

client_scripts {
    'client.lua'
}

files {
    'stream' 
}
